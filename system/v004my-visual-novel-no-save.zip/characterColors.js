
const characterColors = {
  "アカリ": "#ff66cc",
  "？？？": "#00ffff",
  "ユウト": "#ffa500"
};
