const characterStyles = {
  "": { fontSize: "1em", speed: 40 },
  "緋奈": { fontSize: "1.2em", speed: 30 },
  "藍": { fontSize: "1em", speed: 50 },
  "翠": { fontSize: "1.1em", speed: 40 },
  "こがね": { fontSize: "1.3em", speed: 25 },
  "琥珀": { fontSize: "1.1em", speed: 35 }
};