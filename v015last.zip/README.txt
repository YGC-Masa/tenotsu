【v015last ノベルゲームエンジン】

■ 構成フォルダ
project-root/
├── index.html
├── style.css
├── script.js
├── config.js
├── effect.js
├── characterColors.js
├── characterStyles.js
├── assets2/
│   ├── char/         ← キャラ画像（a01002.pngなど）
│   ├── bgev/         ← 背景・イベント画像（bg011.jpgなど）
│   └── bgm/          ← BGM（main.mp3など）
└── scenario/
    ├── 000start.json ← シナリオ本体
    └── storyeditor.html ← GUIエディタ（ローカル対応）

■ シナリオ構成ルール
- JSONファイルで記述（scenes[]内に複数シーン）
- 各シーンに指定可能なキー：
  - bg（背景画像ファイル名）
  - bgEffect（エフェクト名：fadein, whiteoutなど）
  - bgm（BGMファイル名）
  - characters（左右中央のキャラ配置）
  - name（発言者名）※空でも可
  - text（発言内容）
  - choices（{text, jump} の配列）

■ 特記事項
- キャラ画像は保持、NULL指定で明示退場
- オートモード：背景ダブルクリックでON/OFF
- モバイル表示調整済み、--vh 対応
- エフェクトは指定なき場合デフォルト（fadein）
- storyeditor.htmlにて簡易シーン作成可
