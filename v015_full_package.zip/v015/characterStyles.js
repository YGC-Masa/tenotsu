export const characterStyles = {
  緋奈: { font: '1.2em sans-serif' },
  藍: { font: '1.2em serif' },
  翠: { font: '1.2em sans-serif' },
  こがね: { font: '1.2em cursive' },
  琥珀: { font: '1.2em monospace' },
};