export const characterStyles = {
  "緋奈": { font: "sans-serif" },
  "藍": { font: "serif" },
  "翠": { font: "monospace" },
  "こがね": { font: "cursive" },
  "琥珀": { font: "sans-serif" }
};