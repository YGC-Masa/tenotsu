export const config = {
  bgPath: "../assets2/bgev/",
  charPath: "../assets2/char/",
  bgmPath: "../assets2/bgm/",
  scenarioPath: "./scenario/",
};